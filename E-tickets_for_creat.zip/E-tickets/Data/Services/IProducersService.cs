﻿using E_tickets.Data.Base;
using E_tickets.Models;

namespace E_tickets.Data.Services
{
    public interface IProducersService : IEntityBaseRepository<Producer>
    {
    }
}
