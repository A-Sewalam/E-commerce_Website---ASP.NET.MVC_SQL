﻿namespace E_tickets.Data.Enums
{
    public enum MovieCategory
    {
        Action = 1,
        Comedy,
        Drama,
        Documentary,
        Horror,
        Cartoon
    }
}
