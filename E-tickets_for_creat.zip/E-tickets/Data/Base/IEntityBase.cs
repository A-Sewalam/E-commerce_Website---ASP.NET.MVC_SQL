﻿namespace E_tickets.Data.Base
{
    public interface IEntityBase
    {
        int Id { get; set; }
    }
}
